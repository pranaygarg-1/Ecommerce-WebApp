import slider_img_1 from "../assets/images/slider-img-1.png";
import slider_img_2 from "../assets/images/slider-img-2.png";
import slider_img_3 from "../assets/images/slider-img-3.png";
import spinner from "../assets/images/spinner.svg";
import error from "../assets/images/error.png";

const sliderImages =  [slider_img_1, slider_img_2, slider_img_3];
export {sliderImages, spinner, error};